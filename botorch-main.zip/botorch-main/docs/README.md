This directory contains the source files for BoTorch's Docusaurus documentation.
See the website's [README](../website/README.md) for additional information.
