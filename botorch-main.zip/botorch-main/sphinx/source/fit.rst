.. role:: hidden
    :class: hidden-section


botorch.fit
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: botorch.fit
    :members:
