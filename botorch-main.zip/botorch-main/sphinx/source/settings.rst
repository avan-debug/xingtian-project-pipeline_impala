.. role:: hidden
    :class: hidden-section


botorch.settings
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.. automodule:: botorch.settings
    :members:
